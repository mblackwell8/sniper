#ifndef USERINP_H_
#define USERINP_H_

#include <regex.h>

#include "common.h"

#define HAND_SPLITTER 			","
#define RANGE_SPLITTER 			"-"

#define RANGE_NO_UPPER_LIMIT 	'+'
#define SUITED 					'S'
#define OFFSUIT 				'O'
#define RANDOM_SUIT 			'x'
#define RANDOM_RANK 			'X'

//#define USE_MAIN

int errno;
int isRegexInited;
regex_t restrict1, restrict2;

int isPercentHandRegexInited;
regex_t percentHandRestrict;

const char* getError();

int getNumSimsFromUser(); 

//cards are numbered 0-51, with lowest two bits the suit, and next 6 bits the rank
//the carddeck parse method implements this pattern


//returns the number of players (including me)
int getHandsFromUser(char* hands, int numHands[]);

void outputHands(char *handCodes);

int validateHand(char* handCode);
int isPercentHand(const char* handCode);

//internal methods, each of which will return the number of chars put on output array
//first stage deals with full, CSV string eg. AJs-AKs, JJ+, 
int getPossibleHands_csvHandCode(char* handCode, char* output);
//second stage deals with individual hand sets eg. AJs-AKs or JJ+
int getPossibleHands_possRangeHandCode(char* handCode, char* output);

//third stage deals with all individual hands, whether suited or unsuited is specified
//eg. AJs,AQs,AKs,JJ,QQ,KK.AA
int getPossibleHands_looseSingleHandCode(char* handCode, char* output);

//final stage figures the precise hands AJs,AQs,AKs,JJo,QQo,KKo,AAo
int getPossibleHands_preciseSingleHandCode(char* handCode, char* output);

void getRankRange(char firstLetter, char secondLetter, char skipCard, char* rankRange);
int isReverseOrder(char firstLetter, char secondLetter);
void getNoLimitUpperBound(char* existingHandCode, char* upperBound);
void toUpper(char* str);
int hasRandomRank(char* handCode);
int hasRandomSuit(char* handCode);

void test();
void printHands(char* hands, int numHands);

#endif /*USERINP_H_*/
