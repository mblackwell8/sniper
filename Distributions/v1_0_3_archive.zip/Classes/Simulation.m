//
//  Simulation.m
//  sniper
//
//  Created by Mark Blackwell on 16/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Simulation.h"


@implementation Simulation

@synthesize numPlayers;

//@synthesize numHands;
- (int *)numHands {
	return numHands;
}

@synthesize handCodes;

@synthesize numFlopped;
//@property (nonatomic) int numSims;
@synthesize hands;
@synthesize flop;

//- (char *)flop {
//	return flop;
//}
//
//- (void)setFlop:(char *) newflop {
//	flop = newflop;
//}

- (void)setFlopString:(NSString *) flopStr {
	//store the flop cards at the end of the hand buffer
	flop = bufMarker;
	numFlopped = flopStr.length / 2;
	
	[handCodes setObject:flopStr forKey:FLOP_STRING_ARCHIVE_KEY];
	
	NSRange rng;
	rng.location = 0;
	rng.length = 2;
	int i;
	for (i = 0; i < numFlopped; i++) {
		
		//HACK: assumes that the buffer has 10 characters available
		[[flopStr substringWithRange:rng] getCString:bufMarker maxLength:10 encoding:NSASCIIStringEncoding];
		bufMarker[2] = '\0';
		bufMarker += PODDS_CHARS_PER_CARD;
		rng.location += 2;
	}
}

//@synthesize buf;
- (char *)buf {
	return buf;
}

@synthesize bufMarker;

@synthesize numSims;

@synthesize liteTrialCount;

//@synthesize results;
- (simulation_result *)results {
	return results;
}

#pragma mark NSCoding
- (void)encodeWithCoder:(NSCoder *) encoder {
	//always encode the handcodes
	[encoder encodeObject:handCodes forKey:kHandCodeKey];
	
	if (bufMarker == buf) {
		//there is nothing to encode...
		[encoder encodeBool:NO forKey:kWereResultsEncoded];
	}
	else {
		[encoder encodeBool:YES forKey:kWereResultsEncoded];
		
		[encoder encodeInt:numPlayers forKey:kNumPlayersKey];
		[encoder encodeArrayOfObjCType:@encode(int) count:PODDS_MAX_PLAYERS + 1 at:numHands];
		[encoder encodeInt:numFlopped forKey:kNumFloppedKey];
		[encoder encodeInt:(bufMarker - hands) forKey:kBufMarkerOffset];
		[encoder encodeInt:(flop - hands) forKey:kFlopOffset];
		
		int numBufChars = bufMarker - hands;
		[encoder encodeArrayOfObjCType:@encode(char) count:numBufChars at:buf];
		
		//create a string for each simulation_result
		
		//result has three ints
		int i;
		char resultBuf[256];
		for (i = 0; i < PODDS_MAX_PLAYERS + 1; i++) {
			sprintf(resultBuf, "%d,%d,%d", results[i].rounds, results[i].won, results[i].split);
			NSString *key = [NSString stringWithFormat:kResultForPlayerPrefix, i];
			[encoder encodeObject:[NSString stringWithCString:resultBuf encoding:NSASCIIStringEncoding] forKey:key];
		}	
		
		[encoder encodeInt:liteTrialCount forKey:kLiteTrialCount];
	}
}


- (id)initWithCoder:(NSCoder *)decoder {
	if (self = [super init]) {
		//handcodes are always encoded
		self.handCodes = [decoder decodeObjectForKey:kHandCodeKey];
		
		self.numSims = NUM_SIMS;
		
		BOOL isResults = [decoder decodeBoolForKey:kWereResultsEncoded];
		if (isResults ) {
			self.numPlayers = [decoder decodeIntForKey:kNumPlayersKey];
			[decoder decodeArrayOfObjCType:@encode(int) count:PODDS_MAX_PLAYERS + 1 at:numHands];
			self.numFlopped = [decoder decodeIntForKey:kNumFloppedKey];
			self.hands = [self buf];
			self.bufMarker = self.hands + [decoder decodeIntForKey:kBufMarkerOffset];
			self.flop = self.hands + [decoder decodeIntForKey:kFlopOffset];
			
			int numBufChars = bufMarker - hands;
			[decoder decodeArrayOfObjCType:@encode(char) count:numBufChars at:buf];
			
			//decode a string for each simulation_result
			//result has three ints
			int i;
			char resultBuf[256];
			for (i = 0; i < PODDS_MAX_PLAYERS + 1; i++) {
				NSString *key = [NSString stringWithFormat:kResultForPlayerPrefix, i];
				NSString *result = [decoder decodeObjectForKey:key];
				[result getCString:resultBuf maxLength:256 encoding:NSASCIIStringEncoding];
				sscanf(resultBuf, "%d,%d,%d", &results[i].rounds, &results[i].won, &results[i].split);
			}	
		}
		else {
			bufMarker = buf;
			hands = buf;
			flop = NULL;
			numPlayers = 0;
			numFlopped = 0;
		}
		
		self.liteTrialCount = [decoder decodeIntForKey:kLiteTrialCount];
	}
	
	return self;
}

#pragma mark -
#pragma mark NSCopying
- (id)copyWithZone:(NSZone *)zone {
	Simulation *copy = [[[self class] allocWithZone:zone] init];
	copy.numPlayers = self.numPlayers;
	copy.numFlopped = self.numFlopped;
	//copy.numSims = self.numSims;
	//copy.percentDone = self.percentDone;
	
	//hands just points to the start of the buffer
	copy.hands = [copy buf];
	
	//offset the bufmarker the same distance from the start
	copy.bufMarker = [copy buf] + (self.bufMarker - self.buf);
	
	//offset the flop the same way (it's part of the buf)
	copy.flop = [copy buf] + (self.flop - [self buf]);
	
	//HACK: do a shallow copy... but have used "retain" in property??
	copy.handCodes = self.handCodes;
	
	int i;
	for (i = 0; i < PODDS_MAX_PLAYERS + 1; i++) {
		[copy numHands][i] = [self numHands][i];
		
		[copy results][i].rounds = [self results][i].rounds;
		[copy results][i].player = [self results][i].player;
		[copy results][i].won = [self results][i].won;
		[copy results][i].split = [self results][i].split;

		//these fields are ignored...
		//char card1, card2;
		//unsigned int winclasses[10], looseclasses[10];
	}
	
	return copy;
}
#pragma mark -

- (id)init {
    if (self = [super init]) {
        bufMarker = buf;
		hands = buf;
		flop = NULL;
		numPlayers = 0;
		numFlopped = 0;
		numSims = NUM_SIMS;
		
		handCodes = [[NSMutableDictionary alloc] init];
    }
	
    return self;
}

- (void)reset {
	bufMarker = buf;
	flop = NULL;
	numPlayers = 0;
	numFlopped = 0;
	
	int p;
	for (p = 0; p < PODDS_MAX_PLAYERS + 1; p++) {
		results[p].rounds = 0;
		results[p].player = 0;
		results[p].won = 0;
		results[p].split = 0;
	}	
	
	[handCodes removeAllObjects];
}

- (BOOL)addPlayer:(NSString *)handCode at:(NSUInteger) index {
	int charCount = expandHands(handCode, bufMarker);
	if (charCount > 0) {
		bufMarker += charCount;
		//this should be a round number...
		numHands[numPlayers++] = charCount / (PODDS_NUM_DEALT_CARDS * PODDS_CHARS_PER_CARD);
		
		int p;
		for (p = 0; p < PODDS_MAX_PLAYERS + 1; p++)
			results[p].player = numPlayers;
		
		[handCodes setObject:handCode forKey:[NSString stringWithFormat:@"%d", index]];
		
		return YES;
	}
	
	return NO;
}

- (void)dealloc {
    [super dealloc];
	
	[handCodes release];
}



@end

int expandHands(NSString* handCode, char* handBuf) {
	char inbuf[1024];
	
	[handCode getCString:inbuf maxLength:1024 encoding:NSASCIIStringEncoding];
	int charCount = getPossibleHands_csvHandCode(inbuf, handBuf);
	
	return charCount;
}
