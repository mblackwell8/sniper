//
//  SwitchViewController.m
//  sniper
//
//  Created by Mark Blackwell on 7/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "SwitchViewController.h"
#import "SniperViewController.h"
#import "InfoViewController.h"



@implementation SwitchViewController

@synthesize sniperVC;
@synthesize helpInfoVC;
@synthesize aboutInfoVC;
@synthesize currentVC;

- (IBAction)showAboutView:(id)sender {
	NSLog(@"showAboutView called\n");
	//if it's already showing, do nothing...
	if (self.currentVC == self.aboutInfoVC)
		return;
	
	//lazy load
	if (self.aboutInfoVC == nil) {
		InfoViewController *ivc = [[InfoViewController alloc] initWithNibName:@"InfoViewController" bundle:nil];
		
		//need to load the view before can interrogate any of the controls...
		//[ivc loadView];
		//[ivc loadHtmlFromFile:@"aboutSniper"];
#ifdef USE_TRADITIONAL_LITE 
		ivc.resourceFileName = @"aboutSniper_LITE";		
#else
		ivc.resourceFileName = @"aboutSniper";
#endif		
		self.aboutInfoVC = ivc;
		[ivc release];
	}
	
	[self animateTransition:UIViewAnimationTransitionCurlUp incoming:aboutInfoVC outgoing:currentVC];
	
	self.currentVC = self.aboutInfoVC;

}

- (IBAction)showHelpView:(id)sender {
	NSLog(@"showHelpView called\n");
	//if it's already showing, do nothing...
	if (self.currentVC == self.helpInfoVC)
		return;
	
	//lazy load
	if (self.helpInfoVC == nil) {
		InfoViewController *ivc = [[InfoViewController alloc] initWithNibName:@"InfoViewController" bundle:nil];
		
		//need to load the view before can interrogate any of the controls...
		//[ivc loadView];
		//[ivc loadHtmlFromFile:@"help"];
		ivc.resourceFileName = @"help";
		

		self.helpInfoVC = ivc;
		[ivc release];
	}
			
	[self animateTransition:UIViewAnimationTransitionCurlUp incoming:helpInfoVC outgoing:currentVC];
	
	self.currentVC = self.helpInfoVC;
}

- (IBAction)showHomeView:(id)sender {
	NSLog(@"showHomeView called\n");
	if (self.currentVC == self.sniperVC)
		return;
	
	//NSLog([NSString stringWithFormat:@"currentVC at %@, sniperVC at %@\n", currentVC, sniperVC]);
	
	NSLog(@"showHomeView called 2\n");
	
	[self animateTransition:UIViewAnimationTransitionCurlUp incoming:sniperVC outgoing:currentVC];
	
	NSLog(@"showHomeView called 3\n");
	
	self.currentVC = self.sniperVC;
}

//- (void)fillInfoView:(InfoViewController *) ivc withTextFromFile:(NSString *)infoFileName {
//	NSString *appPath = [[NSBundle mainBundle] resourcePath];
//	appPath = [appPath stringByAppendingString:@"/"];
//	
//	NSString *info = [NSString stringWithContentsOfFile:[appPath stringByAppendingString:infoFileName] 
//											   encoding:NSUTF8StringEncoding
//												  error:NULL];
//	
//	[ivc setInfo:info];
//}

- (void)animateTransition:(UIViewAnimationTransition) transition 
				 incoming:(UIViewController *) coming 
				 outgoing:(UIViewController *) going {
//	[going.view removeFromSuperview];
//	[self.view insertSubview:coming.view atIndex:0];
	
	[UIView beginAnimations:@"View Flip" context:nil];
	[UIView setAnimationDuration:0.75];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationTransition:transition forView:self.view cache:YES];
	NSLog(@"animateTransition called 1\n");
	[coming viewWillAppear:YES];
	[going viewWillDisappear:YES];
	NSLog(@"animateTransition called 2\n");
	[going.view removeFromSuperview];
	NSLog(@"animateTransition called 3\n");
	[self.view insertSubview:coming.view atIndex:0];
	NSLog(@"animateTransition called 4\n");
	[going viewDidDisappear:YES];
	[coming viewDidAppear:YES];
	
	[UIView commitAnimations];
		
		NSLog(@"finished animation\n");
}

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform 
 // customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	NSLog(@"SwitchVC viewDidLoad called\n");
	
	SniperViewController *svc = [[SniperViewController alloc] initWithNibName:@"SniperViewController" bundle:nil];
	self.sniperVC = svc;
	self.currentVC = sniperVC;
	[self.view insertSubview:svc.view atIndex:0];
	[svc release];
		
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	NSLog(@"SwitchVC received mem warning\n");

	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.

}

- (void)viewDidUnload {
	NSLog(@"SwitchVC viewDidUnload\n");

	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	if (currentVC == sniperVC) {
		[helpInfoVC release];
		self.helpInfoVC = nil;
		[aboutInfoVC release];
		self.aboutInfoVC = nil;
	}
}


- (void)dealloc {
	[sniperVC release];
	[helpInfoVC release];
	[aboutInfoVC release];
    [super dealloc];
}


@end
