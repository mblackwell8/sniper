//
//  sniperAppDelegate.m
//  sniper
//
//  Created by Mark Blackwell on 28/03/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "SniperAppDelegate.h"
#import "SwitchViewController.h"

@implementation SniperAppDelegate

@synthesize window;
@synthesize switchVC;
@synthesize switchVC;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:switchVC.view];
    [window makeKeyAndVisible];
}

- (void)dealloc {
    [switchVC release];
    [window release];
    [super dealloc];
}


@end
