//
//  PSSimulation.m
//  sniper
//
//  Created by Mark Blackwell on 27/04/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "PSSimulation.h"


@implementation PSSimulation

@synthesize numSims;
@synthesize numPlayers;
@synthesize numHands;
@synthesize percentDone;
@synthesize results;

@synthesize hands;



@end
