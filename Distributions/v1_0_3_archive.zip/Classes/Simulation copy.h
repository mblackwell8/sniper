//
//  Simulation.h
//  sniper
//
//  Created by Mark Blackwell on 16/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "podds.h"

//must be at least (PODDS_MAX_PLAYERS + 1) * PODDS_MAX_HANDS_PER_PLAYER * PODDS_NUM_DEALT_CARDS * PODDS_CHARS_PER_CARD
//this was 1024*8 but that is much larger than required and causes the initFromCoder code to run VERY slowly
//(crashing the device)
#define SIMULATION_BUFSIZE 1024*8
#define kNumPlayersKey @"numPlayers"
#define kNumFloppedKey @"numFlopped"
#define kResultForPlayerPrefix @"resultForPlayer%d"
#define kBufMarkerOffset @"bufMarkerOffset"
#define kFlopOffset @"flopOffset"
#define kHandCodeKey @"handCodes"
#define kWereResultsEncoded @"WereResultsEncoded"
//#define kBufKey @"buffer"
#define NUM_SIMS 1000000
#define FLOP_STRING_ARCHIVE_KEY @"flopStr"

//typedef struct simulation_result {
//	unsigned int rounds;
//	unsigned int player; /* Number of opponents (1 for heads-up) */
//	unsigned int won;
//	unsigned int split;
//	char card1, card2;
//	unsigned int winclasses[10], looseclasses[10];
//} simulation_result; 

@interface Simulation : NSObject <NSCoding, NSCopying> {
	char buf[SIMULATION_BUFSIZE];
	char *bufMarker;
	

@public
	int numPlayers;
	int numHands[PODDS_MAX_PLAYERS + 1];
	int numFlopped;
	int numSims;
	NSMutableDictionary *handCodes;
	
	char *hands;
	char *flop;
	
	//int percentDone;
	
	simulation_result results[PODDS_MAX_PLAYERS + 1];
	

}

@property (nonatomic) int numPlayers;
@property (nonatomic) int *numHands;
@property (nonatomic) int numFlopped;
@property (nonatomic) int numSims;
@property (nonatomic) char *hands;
@property (nonatomic) char *flop;
@property (nonatomic, retain) NSMutableDictionary *handCodes;
//- (void)setFlop:(char *) newflop;
- (void)setFlopString:(NSString *) flopStr;

@property (nonatomic) simulation_result *results;

//these two are really private to the class, but can't seem to have that
//and still access them in the copyWithZone implementation
@property (nonatomic) char *buf;
@property (nonatomic) char *bufMarker;

- (id)init;

- (void)reset;

- (BOOL)addPlayer:(NSString *)handCode at:(NSUInteger) index;

@end

//returns the number of chars written to the handBuf for the player, or -error code if invalid hand
int expandHands(NSString* handCode, char* handBuf);

