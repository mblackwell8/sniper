//
//  sniperViewController.m
//  sniper
//
//  Created by Mark Blackwell on 28/03/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "SniperViewController.h"



@implementation SniperViewController

@synthesize lastSim;

#ifdef USE_IN_APP_PURCHASE
@synthesize privateDataFile;
@synthesize formattedLocalFullVersionPrice;
#endif

// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		NSString *archivePath = [self dataFilePath];
		if (USE_ARCHIVE && [[NSFileManager defaultManager] fileExistsAtPath:archivePath]) {
			NSLog(@"Recovering last sim...");
			
			self.lastSim = [NSKeyedUnarchiver unarchiveObjectWithFile:archivePath];
		}
		else {
			//this has the same lifetime as the app, so no need to release it...
			self.lastSim = [[Simulation alloc] init];
		}
		
#ifdef USE_IN_APP_PURCHASE				
		NSString *settingsPath = [self settingsFilePath];
		if ([[NSFileManager defaultManager] fileExistsAtPath:settingsPath]) {
			NSLog(@"Recovering settings...");
			
			self.privateDataFile = [[NSMutableDictionary alloc] initWithContentsOfFile:settingsPath];
		}
		else {
			self.privateDataFile = [[NSMutableDictionary alloc] init];
			[self.privateDataFile setObject:[NSNumber numberWithInt:0] forKey:kLiteTrialCount];
			[self.privateDataFile setObject:[NSNumber numberWithBool:YES] forKey:kIsLiteVersion];
		}
		
		[[SKPaymentQueue defaultQueue] addTransactionObserver:self];
#endif
		
		UIApplication *app = [UIApplication sharedApplication];
		[[NSNotificationCenter defaultCenter] addObserver:self 
												 selector:@selector(applicationWillTerminate:)
													 name:UIApplicationWillTerminateNotification
												   object:app];		
		
    }
    return self;
}

- (void)viewDidLoad {
	//NSLog(@"Starting...");
	NSLog(@"SniperVC viewDidLoad\n");
	
	[self handLabelSelected:playerOneHand];
	
	stopSign = [UIImage imageNamed:@"50px-Stop_cross.png"];
	
	playerHands[0] = playerOneHand;
	playerHands[1] = playerTwoHand;
	playerHands[2] = playerThreeHand;
	playerHands[3] = playerFourHand;
	
	//title seems to be nil in OS3.0 builds, which interferes with operation
	int p;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		[playerHands[p] setTitle:@"" forState:UIControlStateNormal];
		playerHands[p].titleLabel.adjustsFontSizeToFitWidth = YES; 
	}
	[flop setTitle:@"" forState:UIControlStateNormal];
	flopRiverTurnButton.titleLabel.lineBreakMode = UILineBreakModeWordWrap;
	flopRiverTurnButton.titleLabel.numberOfLines = 2;
	flopRiverTurnButton.titleLabel.textAlignment = UITextAlignmentCenter;

	
	playerPercentInfos[0] = playerOnePercentInfo;
	playerPercentInfos[1] = playerTwoPercentInfo;
	playerPercentInfos[2] = playerThreePercentInfo;
	playerPercentInfos[3] = playerFourPercentInfo;	
	
	playerEqs[0] = playerOneEq;
	playerEqs[1] = playerTwoEq;
	playerEqs[2] = playerThreeEq;
	playerEqs[3] = playerFourEq;
	
	playerOdds[0] = playerOneOdds;
	playerOdds[1] = playerTwoOdds;
	playerOdds[2] = playerThreeOdds;
	playerOdds[3] = playerFourOdds;	
	
	playerWins[0] = playerOneWins;
	playerWins[1] = playerTwoWins;
	playerWins[2] = playerThreeWins;
	playerWins[3] = playerFourWins;	
	
	playerLosses[0] = playerOneLosses;
	playerLosses[1] = playerTwoLosses;
	playerLosses[2] = playerThreeLosses;
	playerLosses[3] = playerFourLosses;	
	
	playerTies[0] = playerOneTies;
	playerTies[1] = playerTwoTies;
	playerTies[2] = playerThreeTies;
	playerTies[3] = playerFourTies;	
	
	NSLog(@"SniperVC viewDidLoad 2\n");
	
	NSString *handCode;
	int i;
	for (i = 0; i < MAX_PLAYERS_ON_SCREEN; i++) {
		if ((handCode = [lastSim.handCodes objectForKey:[NSString stringWithFormat:@"%d", i]]) != nil) {
			[playerHands[i] setTitle:handCode forState:UIControlStateNormal];
			if (handCode.length <= 4) {
				if (isPercentHand([handCode cStringUsingEncoding:NSASCIIStringEncoding])) {
					NSString *percentHandExpl = percentageHandLabel(playerHands[i].currentTitle);
					playerPercentInfos[i].text = percentHandExpl;
				}
			}
		}
	}
	
	if ((handCode = [lastSim.handCodes objectForKey:FLOP_STRING_ARCHIVE_KEY]) != nil)
		[flop setTitle:handCode forState:UIControlStateNormal];
	
	[self updateFlopRiverTurnButton];
	
	[self updateProgress];
	
	NSLog(@"SniperVC viewDidLoad 3\n");
	
	if (!isInited) {
		[NSThread detachNewThreadSelector:@selector(initWorker) toTarget:self withObject:nil];
		isInited = YES;
	}
	
	NSLog(@"SniperVC viewDidLoad 4\n");
	
	[super viewDidLoad];
}

- (NSString *)dataFilePath {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *docsDirectory = [paths objectAtIndex:0];
	return [docsDirectory stringByAppendingPathComponent:ARCHIVE_NAME];
}

- (NSString *)settingsFilePath {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *docsDirectory = [paths objectAtIndex:0];
	return [docsDirectory stringByAppendingPathComponent:SNIPER_PRIVATE_DATAFILE_NAME];
}

- (void)initWorker {
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	if (!isHandEvalInited) {
		//how do i lock isHandEvalInited?  could use a C semaphore??
		//NSLog(@"Initialising 0...");
						
		//NSLog(@"Initialising 1...");
		//init_deck(&deck);
		
		NSString *appPath = [[NSBundle mainBundle] resourcePath];
		
		//NSLog(@"Initialising 2...");
		
		appPath = [appPath stringByAppendingString:@"/"];
		
		//NSLog(@"Initialising 3...");
		//NSString *appDir = [appPath stringByDeletingPathExtension];
		char buf[1024];
		[appPath getCString:buf maxLength:512 encoding:NSASCIIStringEncoding];
		
		NSLog(@"Initialising 4...");
		
		handeval_init(buf);
		
		//NSLog(@"Initialising 5...");
		
		init_random ( time(NULL) );
		
		//NSLog(@"Initialising 6...");
		
		//numIters.text = @"Init'd";
		NSLog(@"Finished initialising");
		
		isHandEvalInited = YES;
		
		[self performSelectorOnMainThread:@selector(enablePostInit)
							   withObject:nil
							waitUntilDone:YES];		
	}
	
	[pool release];

}

- (void)enablePostInit {
	waitInitLabel.hidden = YES;
	[runButton setTitle:@"=" forState:UIControlStateNormal];
	runButton.enabled = YES;
}

- (IBAction)buttonPressed:(id) sender {
	if ([self isActiveLabelPercentHand])
		return;

	UIButton *btn = (UIButton*)sender;
	
	//NSLog([NSString stringWithFormat:@"entering buttonPressed %@", activeLabel.currentTitle]);
	
	[self appendActiveLabel:btn.currentTitle];
	
	[self validateActiveLabel];
	
	//NSLog([NSString stringWithFormat:@"exiting buttonPressed %@", activeLabel.currentTitle]);
}

- (void)appendActiveLabel:(NSString*)card {
	if (activeLabel != nil) {
		//NSLog([NSString stringWithFormat:@"appending %@", card]);
		[activeLabel setTitle:[activeLabel.currentTitle stringByAppendingString:card] forState:UIControlStateNormal];
	}
}

- (IBAction)percentPressed:(id) sender {
	if (activeLabel == flop)
		return;
	
	if ([self isActiveLabelPercentHand])
		return;
	
	[self appendActiveLabel:@"%"];
	
	NSString *percentHandExpl = percentageHandLabel(activeLabel.currentTitle);
	playerPercentInfos[activeLabel.tag - 1].text = percentHandExpl;
	
	[self validateActiveLabel];
}

- (BOOL)isActiveLabelPercentHand {
	if (activeLabel == nil)
		return NO;
	
	NSUInteger len = [activeLabel.currentTitle length];
	return (len > 0 && [activeLabel.titleLabel.text characterAtIndex:(len - 1)] == '%');
}

- (IBAction)heartsPressed:(id) sender {
	if ([self isActiveLabelPercentHand])
		return;

	[self appendActiveLabel:@"h"];
	
	[self validateActiveLabel];
}

- (IBAction)diamondsPressed:(id) sender {
	if ([self isActiveLabelPercentHand])
		return;

	[self appendActiveLabel:@"d"];
	
	[self validateActiveLabel];
}

- (IBAction)spadesPressed:(id) sender {
	if ([self isActiveLabelPercentHand])
		return;

	[self appendActiveLabel:@"s"];
	
	[self validateActiveLabel];
}

- (IBAction)clubsPressed:(id) sender {
	if ([self isActiveLabelPercentHand])
		return;

	[self appendActiveLabel:@"c"];
	
	[self validateActiveLabel];
}

- (void)flipsideViewControllerDidFinish:(FlipsideViewController *)controller {
    
	[self dismissModalViewControllerAnimated:YES];
}

- (IBAction)backspacePressed:(id) sender {
	if (activeLabel != nil) {
		NSUInteger len = [activeLabel.currentTitle length];
		if (len > 0) {
			if ([self isActiveLabelPercentHand])
				playerPercentInfos[activeLabel.tag - 1].text = @"";
			
			[activeLabel setTitle:[activeLabel.currentTitle substringToIndex:(len - 1)] forState:UIControlStateNormal];
		}
		
		[self validateActiveLabel];
	}
}

- (IBAction)clearPressed:(id) sender {
	if (activeLabel != nil) {
		[activeLabel setTitle:@"" forState:UIControlStateNormal];
		
		if (activeLabel != flop)
			playerPercentInfos[activeLabel.tag - 1].text = @"";
	}
}

- (IBAction)clearDoublePressed:(id)sender {
	int p;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		[playerHands[p] setTitle:@"" forState:UIControlStateNormal];
		playerPercentInfos[p].text = @"";
	}
	
	[flop setTitle:@"" forState:UIControlStateNormal];
	
	[lastSim reset];
	
	[self updateProgress];
}

- (IBAction)handLabelSelected:(id)sender {
	
	//remove any existing highlight
	if (activeLabel != nil)
		activeLabel.backgroundColor = nil;			
	
	
	activeLabel = (UIButton*)sender;
	
	//highlight selection white
	activeLabel.backgroundColor = [UIColor whiteColor];
}

- (IBAction)randomHandPressed:(id) sender {
	if ([self isActiveLabelPercentHand])
		return;

	if (activeLabel == nil)
		return;
	
	if (activeLabel == flop) 
		return;
	
	[activeLabel setTitle:@"xxxx" forState:UIControlStateNormal];
}

- (IBAction)cycleFlopRiverTurn:(id)sender {
	if (lastSim == nil)
		return;
	
	if (lastSim.numCards != PODDS_RIVER_CARDS_PER_HAND)
		lastSim.numCards++;
	else
		lastSim.numCards = PODDS_FLOP_CARDS_PER_HAND;
	
	[self updateFlopRiverTurnButton];
	
	if (lastSim.isFirstFlopRiverTurnCycle) {
		[SniperViewController displayAlert:@"By default, PokerSniper deals to the river, meaning that hand equity is calculated on all 7 cards (2 + 5).  Deal to flop ends the hand and calculates equity with 3 community cards dealt, whilst Deal to turn ends the hand with 4 community cards dealt.  This message will not be shown again." entitled:@"Deal to FLOP/TURN/RIVER"];
		lastSim.isFirstFlopRiverTurnCycle = NO;
	}
}

- (void)updateFlopRiverTurnButton {
	assert_local (lastSim.numCards >= PODDS_FLOP_CARDS_PER_HAND && lastSim.numCards <= PODDS_RIVER_CARDS_PER_HAND);
	
	switch (lastSim.numCards) {
		case PODDS_FLOP_CARDS_PER_HAND:
			[flopRiverTurnButton setTitle:@"Deal to FLOP" forState:UIControlStateNormal];
			[flopRiverTurnButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
			break;
		case PODDS_TURN_CARDS_PER_HAND:
			[flopRiverTurnButton setTitle:@"Deal to TURN" forState:UIControlStateNormal];
			[flopRiverTurnButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
			break;
		case PODDS_RIVER_CARDS_PER_HAND:
			[flopRiverTurnButton setTitle:@"Deal to RIVER" forState:UIControlStateNormal];
			[flopRiverTurnButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
			break;
	}
}

- (BOOL)validateActiveLabel {
	if (![self validateLabel:activeLabel]) {
		[activeLabel setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
		//NSLog([NSString stringWithFormat:@"Invalid label %@", activeLabel.currentTitle]);
		return NO;
	}
	
	[activeLabel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
	//NSLog([NSString stringWithFormat:@"Valid label %@", activeLabel.currentTitle]);
	return YES;
}

- (BOOL)validateLabel:(UIButton *) label {
	//flop is separately validated
	if (label == flop)
		return YES;
	
	char validateBuf[256];
	[label.currentTitle getCString:validateBuf maxLength:256 encoding:NSASCIIStringEncoding];
	if (validateHand(validateBuf)) 
		return NO;
	
	return YES;
}

- (IBAction)switchHandEquityPresentationPressed:(id) sender {
	isResultsDisplaySwitched = !isResultsDisplaySwitched;
	
	if (!isWorking)
		[self updateProgress];
}


- (IBAction)showHelp {    
	
	FlipsideViewController *controller = [[FlipsideViewController alloc] initWithNibName:@"FlipsideView" bundle:nil];
	controller.delegate = self;
	
#ifdef USE_TRADITIONAL_LITE
	controller.resourceFileName = @"help_LITE";
#else
	controller.resourceFileName = @"help";
#endif
	
	controller.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
	[self presentModalViewController:controller animated:YES];
	
	[controller release];
}


- (IBAction)runPressed:(id) sender {
	if (isWorking && isWorkerCancelled) {
		//do nothing... wait for the cancellation to take effect
	}
	else if (isWorking) {
		isWorkerCancelled = YES;
		//change image to = sign
		[runButton setTitle:@"=" forState:UIControlStateNormal];
		[runButton setImage:nil forState:UIControlStateNormal];

	}
	else if (isHandEvalInited) {
#ifdef USE_IN_APP_PURCHASE
		if ([[self privateDataFile] objectForKey:kIsLiteVersion]) {
			[self showNagDialog];
			int trialCount = [[[self privateDataFile] objectForKey:kLiteTrialCount] intValue];
			if (trialCount >= SNIPER_LITE_TRIALS) {
				//[SniperViewController displayError:@"You have reached the maximum number of trials." entitled:@"Sorry"];
				return;
			}
			
			[self.privateDataFile setObject:[NSNumber numberWithInt:(trialCount + 1)] forKey:kLiteTrialCount];
		}
#endif	
#ifdef USE_TRADITIONAL_LITE
		[self showNagDialog];
		if (lastSim.liteTrialCount >= SNIPER_LITE_TRIALS) {
			//[SniperViewController displayError:@"You have reached the maximum number of trials." entitled:@"Sorry"];
			return;
		}
				
		lastSim.liteTrialCount++;
		
#endif
		isWorkerCancelled = NO;
		
		if([self run]) {
			//change image to stop sign
			[runButton setTitle:@"" forState:UIControlStateNormal];
			[runButton setImage:stopSign forState:UIControlStateNormal];
		}
	}
	else {
		//hand eval not inited
		[SniperViewController displayAlert:@"PokerSniper hasn't quite finished initialising yet... please try again in a few moments"
								  entitled:@"Sorry..."];
	}
	
	//NSLog(@"Leaving runPressed");
}

#ifdef USE_IN_APP_PURCHASE
- (void)showNagDialog {
	int trials = [[[self privateDataFile] objectForKey:kLiteTrialCount] intValue];
	if ((trials > SNIPER_LITE_START_NAG_AT_TRIAL_NUM) && (trials % SNIPER_LITE_TRIALS_BETWEEN_NAGS) == 0) {
		
		// if we don't know the price of the full version, find out
		
		if (self.formattedLocalFullVersionPrice == nil) {
			NSSet *pid = [NSSet setWithObject:kUpgradeIdentifier];
			SKProductsRequest *request = [[SKProductsRequest alloc] initWithProductIdentifiers:pid];
			request.delegate = self;
			[request start];
			
			[request release];
		}
		
		NSDate *stopWaiting = [NSDate dateWithTimeIntervalSinceNow:(APPSTORE_MAX_WAIT_MILLIS / 1000)];
		while (self.formattedLocalFullVersionPrice == nil && [stopWaiting timeIntervalSinceNow] > 0) {
			[NSThread sleepForTimeInterval:(APPSTORE_MAX_WAIT_MILLIS / 100)];
		}
		
		NSString *price = self.formattedLocalFullVersionPrice;
		if (price == nil)
			price = @"n/a";
		
		NSString *msg;
		if (trials >= SNIPER_LITE_TRIALS)
			msg = [NSString stringWithFormat:@"You have no more free trials... would you like to buy the full version of PokerSniper for %@?",
											price];
		else
			msg = [NSString stringWithFormat:@"You have %d free trials remaining... would you like to buy the full version of PokerSniper for %@?", 
											SNIPER_LITE_TRIALS - trials, price];
		
		UIActionSheet *sheet = [[UIActionSheet alloc] 
								initWithTitle:msg
								delegate:self 
								cancelButtonTitle:nil 
								destructiveButtonTitle:nil 
								otherButtonTitles:@"No thanks", @"Yes please!", nil];
		[sheet showInView:self.view];
		[sheet release];	
	}
}

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {
	SKProduct *sniper = [response.products objectAtIndex:0];
	
	NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
	
	[numberFormatter setFormatterBehavior:NSNumberFormatterBehavior10_4];
	
	[numberFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
	
	[numberFormatter setLocale:sniper.priceLocale];
	
	self.formattedLocalFullVersionPrice = [numberFormatter stringFromNumber:sniper.price];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	switch (buttonIndex) {
		case 0:
			//"No thanks"... do nothing :(
			break;
		case 1:
			//"Yes thanks"... WOOHOO!
			[self purchaseFullVersion];
			break;
			
		default:
			break;
	}
}

- (void)purchaseFullVersion {
	//[[SKPaymentQueue defaultQueue] canMakePayments] ??
	if ([SKPaymentQueue canMakePayments]) {
		SKPayment *payment = [SKPayment paymentWithProductIdentifier:kUpgradeIdentifier];
		
		[[SKPaymentQueue defaultQueue] addPayment:payment];
		
	}
	else {
		
		// Warn the user that purchases are disabled.
		
	}
}

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions {
	
	assert ([transactions count] == 1);
	SKPaymentTransaction *transaction = [transactions objectAtIndex:0];
	switch (transaction.transactionState) {
		case SKPaymentTransactionStatePurchased:
			[privateDataFile setObject:transaction forKey:kPurchaseTranscationDetails];
			[privateDataFile setObject:[NSNumber numberWithBool:NO] forKey:kIsLiteVersion];
			break;
			
		case SKPaymentTransactionStateFailed:
			//todo: tell the user using the error field
			break;
			
		//this is in the sample code, but can't find it in the documentation
		case SKPaymentTransactionStateRestored:
			//do nothing
			break;
			
		default:
			break;
			
	}
	
	[[SKPaymentQueue defaultQueue] finishTransaction: transaction];
}

#endif

#ifdef USE_TRADITIONAL_LITE

- (void)showNagDialog {
	int trials = lastSim.liteTrialCount;
	if ((trials >= SNIPER_LITE_START_NAG_AT_TRIAL_NUM) && (trials % SNIPER_LITE_TRIALS_BETWEEN_NAGS) == 0) {
		
		NSString *msg;
		if (trials >= SNIPER_LITE_TRIALS)
			msg = @"You have no more free trials... would you like to buy the full version of PokerSniper?";
		else
			msg = [NSString stringWithFormat:@"You have %d free trials remaining... would you like to buy the full version of PokerSniper?", 
				   SNIPER_LITE_TRIALS - trials];
		
		isWaitingForFullVersionDecision = YES;
		UIActionSheet *sheet = [[UIActionSheet alloc] 
								initWithTitle:msg
								delegate:self 
								cancelButtonTitle:nil 
								destructiveButtonTitle:nil 
								otherButtonTitles:@"Yes please!", @"No thanks", nil];
		[sheet showInView:self.view];
		
		//wait until we have an answer before doing the calc
		NSRunLoop *theRL = [NSRunLoop currentRunLoop];
		while (isWaitingForFullVersionDecision && [theRL runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]]);
		
		[sheet release];	
	}
}


- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
	switch (buttonIndex) {
		case 0:
			//"Yes thanks"... WOOHOO!
			
			//first save down the simulation file... seems not to happen which puts back 50 trials
			[self applicationWillTerminate:nil];
			
			[[UIApplication sharedApplication] openURL:[NSURL URLWithString:kFullVersionUrl]];
			break;
		case 1:
			//"No thanks"... do nothing :(
			break;
			
		default:
			break;
	}
	isWaitingForFullVersionDecision = NO;
}

#endif


- (BOOL)run {
	
	//user alert already occurred... just being defensive
	if (!isHandEvalInited)
		return NO;
	
	if ([self checkHandCollision])
		return NO;
		
	[self checkEasterEgg];
	
	int p, blanks = 0; //, validHandIx = 0;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		if ([playerHands[p].currentTitle isEqualToString:@""]) {
			blanks++;
			continue;
		}
	}
	
	if (blanks == MAX_PLAYERS_ON_SCREEN) {
		[SniperViewController displayAlert:@"No hands entered!" entitled:@"Whoops!"];
		return NO;
	}
	
	// including me
	//int numPlayers = [self countPlayers];lastSim
	[lastSim reset];
	
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		if ([playerHands[p].currentTitle isEqualToString:@""])
			continue;
		
		if ([playerHands[p].currentTitle isEqualToString:@"x"]) {
			[playerHands[p] setTitle:@"xxxx" forState:UIControlStateNormal];
			[playerHands[p] setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

		}
		
		if (![self validateLabel:playerHands[p]]) {
			[SniperViewController displayAlert:[NSString stringWithFormat:@"Error in hand %d", p + 1] entitled:@"Whoops!"];
			
			return NO;
		}
		
		if (![lastSim addPlayer:playerHands[p].currentTitle at:p]) {
			//report error
			NSString *errStr = [NSString stringWithCString:getError() encoding:NSASCIIStringEncoding];
			[SniperViewController displayAlert:errStr entitled:[NSString stringWithFormat:@"Error in hand %d", p + 1]];
			
			return NO;
		}
	}
	
	//parse the flop cards
	NSString *flopStr = flop.currentTitle;
	//int i;
	
	//must be an even number of characters (number plus suit for each card)
	BOOL isErr = ((flopStr.length % 2) != 0);
	NSRange rng;
	rng.location = 0;
	rng.length = 2;
	while (!isErr && (rng.location + rng.length) <= flopStr.length) {
		isErr = !([SniperViewController isCard:[flopStr substringWithRange:rng]]);
		rng.location += 2;
	}
	
	if (isErr) {
		[SniperViewController displayAlert:@"Cards must each have card and rank" entitled:@"Error in flop"];
		
		return NO;
	}
	
	[lastSim setFlopString:flopStr];
	
	if ([self checkFlopVsDealMode])
		return NO;
	
//	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
//		lastSim.results[p].player = numPlayers;
//	}	
	
	//NSLog(@"Launching worker...");
	
	//run processing in worker thread
	[NSThread detachNewThreadSelector:@selector(runWorker) toTarget:self withObject:nil];
	
	//NSLog(@"Worker started");
	
	return YES;
}

- (void)checkEasterEgg {
	int p; //, validHandIx = 0;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		if ([playerHands[p].currentTitle isEqualToString:@"J3s"]) {
		    [SniperViewController displayAlert:@"If you really played J3s, then not even PokerSniper can help you." 
									  entitled:@"Uh oh :)"];
			return;
		}
	}
}

- (BOOL)checkFlopVsDealMode {
	if ((flop.currentTitle.length / 2) + PODDS_NUM_DEALT_CARDS > lastSim.numCards) {
		[SniperViewController displayAlert:[NSString stringWithFormat:@"Too many flop cards specified for '%@'", flopRiverTurnButton.currentTitle] 
								  entitled:@"Error"];
		return YES;
	}
	
	return NO;
}

+ (BOOL)isCard:(NSString*) card {
	BOOL isErr = (card.length != 2);
	int i;
	for (i = 0; (!isErr) && i < card.length; i++) {
		if (i % 2 == 0) {
			unichar number = [card characterAtIndex:i];
			isErr = (number != '2' &&
					 number != '3' &&
					 number != '4' &&
					 number != '5' &&
					 number != '6' &&
					 number != '7' &&
					 number != '8' &&
					 number != '9' &&
					 number != 'T' &&
					 number != 'J' &&
					 number != 'Q' &&
					 number != 'K' &&
					 number != 'A');
		}
		else {
			unichar suit = [card characterAtIndex:i];
			isErr = (suit != 'h' &&
					 suit != 'd' &&
					 suit != 'c' &&
					 suit != 's');
			
		}
	}
	
	return !isErr;
}

- (BOOL)checkHandCollision {
	
	//return NO;

	//check for >4 of the same rank	
	//check for >13 of the same suit
	//check for exact duplicate cards
	
	//take the first specified hands from each player
	//if a range is specified take only the left end of the range
	//ignore if more than one hand combo exists just take the first combo
	//because this makes hand collisions far less likely (ie. they will only
	//exist if every one of the player hands specifies that same card,
	//which is far more likely to be done as a range)
	NSMutableSet *dealtCards = [[NSMutableSet alloc] initWithCapacity:PODDS_NUM_CARDS];
	
	//90 gives access to all nums and letters...
	int suitsPerRank[90] = { 0 };
	
	//hack: splitting hands on any punctuation characters (not just +-, etc)
	NSCharacterSet *splitters = [NSCharacterSet punctuationCharacterSet];
	int p = 0;
	BOOL isCollision = NO;
	while (!isCollision) {
		NSString *hand;
		//check the dealt hands and the flop
		if (p < MAX_PLAYERS_ON_SCREEN)
			hand = playerHands[p].currentTitle;
		else if (p == MAX_PLAYERS_ON_SCREEN)
			hand = flop.currentTitle;
		else
			break;
		p++;
		
		if ([hand isEqual:@""])
			continue;
			
		//just take the first "hand" (which could be anything really... KQ, KdKh, K7s etc etc
		NSString *firstHand = [[hand componentsSeparatedByCharactersInSet:splitters] objectAtIndex:0];

		//if the first two characters are a card, then add then to the set of cards, checking for collisions
		NSRange rng;
		rng.location = 0;
		rng.length = 2;
		while (!isCollision && (rng.location + rng.length) <= firstHand.length) {
			NSString* card = [firstHand substringWithRange:rng];
			if ([SniperViewController isCard:card]) {
				if ([dealtCards containsObject:card]) {
					isCollision = YES;
					
					[SniperViewController displayAlert:[NSString stringWithFormat:@"'%@' occurs twice (or more!)", card]
											  entitled:@"Card overdealt!"];
					break; //out of while
				}
				else {
					[dealtCards addObject:card];
					
					//and add the rank to the suitsPerRank count
					unichar rank = [card characterAtIndex:0];	
					if (++suitsPerRank[(int)rank] > PODDS_NUM_SUITS) {
						isCollision = YES;
						[SniperViewController 
							displayAlert:[NSString stringWithFormat:@"'%c' occurs %d (or more) times", rank, suitsPerRank[(int)rank]]
							entitled:@"Card overdealt!"];
						break; //out of while
					}
				}
			}
			//if the first two characters are not a card, and they are legal, then they must be either two ranks
			//or have a random rank (or maybe suit for something like xhxh)
			else if (rng.location == 0) {
				int i;
				for (i = 0; i < 2; i++) {
					unichar rank = [card characterAtIndex:i];	
					//if 
					if (rank == RANDOM_ENTRY_CHAR)
						break;
					
					if (++suitsPerRank[(int)rank] > PODDS_NUM_SUITS) {
						isCollision = YES;
						[SniperViewController 
							displayAlert:[NSString stringWithFormat:@"'%c' occurs %d (or more) times", rank, suitsPerRank[(int)rank]]
							entitled:@"Card overdealt!"];
						break; //won't break out of while loop immediately, but will on next iter
					}
				}
				
			}
			
			rng.location += 2;
		}
	}

	
	[dealtCards release];
	
	return isCollision;
}

+ (void)displayAlert:(NSString *)msg entitled:(NSString *)title {
	UIAlertView *alert = [[UIAlertView alloc] 
						  initWithTitle:title
						  message:msg
						  delegate:nil 
						  cancelButtonTitle:@"OK" 
						  otherButtonTitles:nil];
	[alert show];
	[alert release];	
}

- (int)countPlayers {
	int p, count = 0;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		if (![playerHands[p].currentTitle isEqualToString:@""])
			count++;
	}
	
	return count;
}

- (void)runWorker {
	//NSLog(@"runWorker started");
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	isWorking = YES;
	
//	clock_t start, end;
//	double elapsed;
//	start = clock();
	
	//NSLog(@"Beginning sim");
#ifdef	DUMP_RESULTS_FILE
	NSMutableData *resultsDump = [NSMutableData dataWithCapacity:1024];
	
#endif		
	
	
	int i;
	for (i = 0; i < lastSim.numSims && !isWorkerCancelled; i++) {
		if (i != 0 && (i % UPDATE_EQ_FREQ) == 0) {
			[self performSelectorOnMainThread:@selector(updateProgress)
								   withObject:nil
								waitUntilDone:YES];
		}

#ifdef DUMP_RESULTS_FILE
		int failed = 
#endif
		runSimulation_ncards(lastSim.hands, lastSim.numPlayers, [lastSim numHands], 
								   lastSim.flop, lastSim.numFlopped, lastSim.numCards, [lastSim results]);
		
#ifdef	DUMP_RESULTS_FILE
		if (!failed) {
			int p;
			char cardBuf[PODDS_CHARS_PER_CARD];
			NSString *playerHandsStr = nil;
			NSString *playerHandnamesStr = nil;
			NSString *winner = @"Split";
			NSString *splits = nil;
			for (p = 0; p < lastSim.numPlayers; p++) {
				hand_to_str(&([lastSim results][p].card1), 1, cardBuf);
				NSString *hand = [NSString stringWithCString:cardBuf encoding:NSASCIIStringEncoding];
				hand_to_str(&([lastSim results][p].card2), 1, cardBuf);
				hand = [hand stringByAppendingString:[NSString stringWithCString:cardBuf encoding:NSASCIIStringEncoding]];
				
				if (!playerHandsStr)
					playerHandsStr = [NSString stringWithString:hand];
				else
					playerHandsStr = [playerHandsStr stringByAppendingString:[NSString stringWithFormat:@",%@", hand]];
				
				NSString *handName = [NSString stringWithCString:[lastSim results][p].handeval->desc encoding:NSASCIIStringEncoding];
				
				if (!playerHandnamesStr)
					playerHandnamesStr = [NSString stringWithString:handName];
				else
					playerHandnamesStr = [playerHandnamesStr stringByAppendingString:[NSString stringWithFormat:@",%@", handName]];
				
				if ([lastSim results][p].isWinner)
					winner = [NSString stringWithFormat:@"P%d", p];
				else if ([lastSim results][p].isSplltter) {
					if (!splits)
						splits = [NSString stringWithFormat:@"P%d", p];
					else
						splits = [splits stringByAppendingString:[NSString stringWithFormat:@",P%d", p]];
				}
			}
			
			char flopBuf[PODDS_NUM_FLOP_CARDS * PODDS_CHARS_PER_CARD];
			
			//just use the flop cards provided in the first result... they are all the same
			hand_to_str([lastSim results][0].flopCards, PODDS_NUM_FLOP_CARDS, flopBuf);
			NSString *flopStr = [NSString stringWithCString:flopBuf encoding:NSASCIIStringEncoding];
			
			NSString *result = [NSString stringWithFormat:@"%@,%@,%@,%@,%@\r\n", playerHandsStr, flopStr, playerHandnamesStr, winner, splits];
			const char *utfResult = [result UTF8String];
			[resultsDump appendBytes:utfResult length:strlen(utfResult)];
		}
#endif
	}
	
	//in practice the cancellation check always seems to occur while the screen updating is taking place
	//so we don't miss out on any simulations by not displaying the final state... and also means that
	//an even number of sims will be displayed, rather than one more
	
//	[self performSelectorOnMainThread:@selector(updateProgress)
//						   withObject:nil
//						waitUntilDone:YES];
	
//	end = clock();
//	elapsed = ((double) (end - start)) / CLOCKS_PER_SEC;
	
#ifdef	DUMP_RESULTS_FILE
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    if (!documentsDirectory) {
        NSLog(@"Documents directory not found!");
    }
	else {
		NSString *appFile = [documentsDirectory stringByAppendingPathComponent:DUMP_RESULTS_FILENAME];
		[resultsDump writeToFile:appFile atomically:YES];
	}
	
#endif
	
	isWorking = NO;
	
    [pool release];
}

- (void)updateProgress {
	int p, activeIx = 0;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		if (![playerHands[p].currentTitle isEqualToString:@""]) {
			
			//hand collisions may mean no rounds are played... hopefully stopped before this point
			if ([lastSim results][activeIx].rounds == 0) {
				continue;
			}
			
			double equity = ((0.5 * [lastSim results][activeIx].split) + [lastSim results][activeIx].won) / [lastSim results][activeIx].rounds;
			//convert equity to pot odds
			double odds = (1 - equity) / equity;
			
			if (!isResultsDisplaySwitched) {
				[playerEqs[p] setText:[NSString stringWithFormat:@"%1.1f%%", (equity * 100)]];			
				[playerOdds[p] setText:[NSString stringWithFormat:@"%1.1f\nto 1", odds]];
			}
			else {
				[playerEqs[p] setText:[NSString stringWithFormat:@"%1.1f to 1", odds]];			
				[playerOdds[p] setText:[NSString stringWithFormat:@"%1.0f%%", (equity * 100)]];
			}
			
			[playerEqs[p] setTextColor:[UIColor blackColor]];
			[playerOdds[p] setTextColor:[UIColor blackColor]];	
			
			int lost = [lastSim results][activeIx].rounds - ([lastSim results][activeIx].won + [lastSim results][activeIx].split);
			[playerWins[p] setText:[NSString stringWithFormat:@"W: %1.0f%%", 
									(float)[lastSim results][activeIx].won / [lastSim results][activeIx].rounds * 100]];
			[playerLosses[p] setText:[NSString stringWithFormat:@"L: %1.0f%%", 
									  (float)lost / [lastSim results][activeIx].rounds * 100]];
			[playerTies[p] setText:[NSString stringWithFormat:@"T: %1.0f%%", 
									(float)[lastSim results][activeIx].split / [lastSim results][activeIx].rounds * 100]];
			
			[playerWins[p] setTextColor:[UIColor blackColor]];
			[playerLosses[p] setTextColor:[UIColor blackColor]];
			[playerTies[p] setTextColor:[UIColor blackColor]];
			
			activeIx++;
		}
		else {
			if (!isResultsDisplaySwitched) {
				[playerEqs[p] setText:@"HE%"];
				[playerOdds[p] setText:@"X.X\nto 1"];		
			}
			else {
				[playerEqs[p] setText:@"X.X to 1"];
				[playerOdds[p] setText:@"HE%"];
			}
			
			[playerEqs[p] setTextColor:[UIColor grayColor]];
			[playerOdds[p] setTextColor:[UIColor grayColor]];	
			
			
			[playerWins[p] setText:@""];//"W:"];
			[playerLosses[p] setText:@""];//"L:"];
			[playerTies[p] setText:@""];//T:"];
			
			[playerWins[p] setTextColor:[UIColor grayColor]];
			[playerLosses[p] setTextColor:[UIColor grayColor]];
			[playerTies[p] setTextColor:[UIColor grayColor]];
		}
	}
	
	[numIters setText:[NSString stringWithFormat:@"%d", [lastSim results][0].rounds]];
}

- (void)applicationWillTerminate:(NSNotification *)notification {
	//save down the hands, flop and any result
	
	NSLog(@"Terminating...");
	
//	int i;
//	for (i = 0; i < MAX_PLAYERS_ON_SCREEN; i++) {
//		[lastSim.handCodes setObject:[playerHands[i] currentTitle] forKey:[NSString stringWithFormat:@"%d", i]];
//	}
	
	NSString *archivePath = [self dataFilePath];
	BOOL wasSuccess = [NSKeyedArchiver archiveRootObject:lastSim toFile:archivePath];
	
	NSLog([NSString stringWithFormat:@"Finished archiving... %d", wasSuccess]);

#ifdef USE_IN_APP_PURCHASE
	NSString *settingsPath = [self settingsFilePath];
	wasSuccess = [[self privateDataFile] writeToFile:settingsPath atomically:YES];
	
	NSLog([NSString stringWithFormat:@"Finished writing settings... %d", wasSuccess]);
#endif	
}





/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)viewDidUnload {
	NSLog(@"SniperVC viewDidUnload\n");
	
	NSLog([NSString stringWithFormat:@"lastSim: %@", lastSim]);
	
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;	
}

- (void)didReceiveMemoryWarning {
	NSLog(@"SniperVC received mem warning\n");
	
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)dealloc {
    [super dealloc];
}

@end

//int expandHands(NSString* handCode, char* handBuf) {
//	char inbuf[1024];
//	
//	[handCode getCString:inbuf maxLength:1024 encoding:NSASCIIStringEncoding];
//	int charCount = getPossibleHands_csvHandCode(inbuf, handBuf);
//	
//	return charCount;
//}
