//
//  FlipsideView.m
//  sniper
//
//  Created by Mark Blackwell on 1/02/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "FlipsideView.h"

@implementation FlipsideView


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {
    [super dealloc];
}


@end
