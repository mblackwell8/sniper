//
//  sniperViewController.h
//  sniper
//
//  Created by Mark Blackwell on 28/03/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import <StoreKit/StoreKit.h>
//#import <StoreKit/SKPaymentQueue.h>

#import "podds.h"
//#import "Fraction.h"
#import "Simulation.h"

#define UPDATE_EQ_FREQ						100

//NB: in userinp.h RANDOM_RANK is 'X' and RANDOM_SUIT is 'x', but this
//is only true after hands have been parsed... at entry it is just 'x'
#define RANDOM_ENTRY_CHAR					'x'
#define ARCHIVE_NAME						@"sniper.archive"
#define MAX_PLAYERS_ON_SCREEN				4
#define CLR_ALL_INTERVAL_SECS				2.0

#define SNIPER_LITE_TRIALS					50
#define SNIPER_LITE_START_NAG_AT_TRIAL_NUM	25
#define SNIPER_LITE_TRIALS_BETWEEN_NAGS		5
#define SNIPER_PRIVATE_DATAFILE_NAME		@"sniper.priv"

#define kLiteTrialCount						@"liteTrialCount"
#define kIsLiteVersion						@"isLiteVersion"
#define kPurchaseTranscationDetails			@"purchaseTransactionDetails"
#define kUpgradeIdentifier					@"com.allieandmark.sniper.full_version"
#define APPSTORE_MAX_WAIT_MILLIS			1000

//#define DUMP_RESULTS_FILE
//#define DUMP_RESULTS_FILENAME @"resultsDump.csv"
#define USE_ARCHIVE YES
//#define USE_IN_APP_PURCHASE
//#define USE_TRADITIONAL_LITE
#define kFullVersionUrl						@"http://itunes.com/app/pokersniper"


//typedef struct {
//	int numPlayers;
//	int numHands[PODDS_MAX_PLAYERS + 1];
//	int numFlopped;
//	int numSims;
//	
//	//must be at least (PODDS_MAX_PLAYERS + 1) * PODDS_MAX_HANDS_PER_PLAYER * PODDS_NUM_DEALT_CARDS * PODDS_CHARS_PER_CARD
//	char buf[1024 * 8];
//	char *hands;
//	char *flop;
//	
//	int percentDone;
//	
//	simulation_result results[PODDS_MAX_PLAYERS + 1];
//} simulation;

@interface SniperViewController : UIViewController <UIActionSheetDelegate
#ifdef USE_IN_APP_PURCHASE
														, SKPaymentTransactionObserver, SKProductsRequestDelegate
#endif 
														> {
	IBOutlet UIButton *playerOneHand;
	IBOutlet UIButton *playerTwoHand;
	IBOutlet UIButton *playerThreeHand;
	IBOutlet UIButton *playerFourHand;
	
	//IBOutlet UIButton *playerOneBackgrd;
	
	UIButton *playerHands[4];
	
	IBOutlet UIButton *flop;
	
	UIButton *activeLabel;
	
	//UIButton *selectedButton;
	
	IBOutlet UILabel *playerOneEq;
	IBOutlet UILabel *playerTwoEq;
	IBOutlet UILabel *playerThreeEq;
	IBOutlet UILabel *playerFourEq;
	
	UILabel *playerEqs[4];
	
	IBOutlet UILabel *playerOneOdds;
	IBOutlet UILabel *playerTwoOdds;
	IBOutlet UILabel *playerThreeOdds;
	IBOutlet UILabel *playerFourOdds;	
	
	UILabel *playerOdds[4];
	
	IBOutlet UILabel *playerOneWins;
	IBOutlet UILabel *playerTwoWins;
	IBOutlet UILabel *playerThreeWins;
	IBOutlet UILabel *playerFourWins;	
	
	UILabel *playerWins[4];
	
	IBOutlet UILabel *playerOneLosses;
	IBOutlet UILabel *playerTwoLosses;
	IBOutlet UILabel *playerThreeLosses;
	IBOutlet UILabel *playerFourLosses;	
	
	UILabel *playerLosses[4];
	
	IBOutlet UILabel *playerOneTies;
	IBOutlet UILabel *playerTwoTies;
	IBOutlet UILabel *playerThreeTies;
	IBOutlet UILabel *playerFourTies;	
	
	UILabel *playerTies[4];
	
	IBOutlet UILabel *numIters;
	
	IBOutlet UIButton *runButton;
	UIImage *stopSign;
	
	Simulation *lastSim;
	
	BOOL isInited;
	
	BOOL isHandEvalInited;
	
	BOOL isWorking;
	
	BOOL isWorkerCancelled;	
	
	BOOL isResultsDisplaySwitched;
	
#ifdef USE_TRADITIONAL_LITE
	BOOL isWaitingForFullVersionDecision;
#endif	
	//NSTimer *clearAllTimer;
	
	BOOL doClearAll;
	
	//BOOL clearPressedLast;
															
#ifdef USE_IN_APP_PURCHASE
	
	NSMutableDictionary *privateDataFile;
	NSString *formattedLocalFullVersionPrice;
#endif
}

@property (retain, nonatomic) Simulation *lastSim;

- (IBAction)buttonPressed:(id) sender;

- (IBAction)heartsPressed:(id) sender;

- (IBAction)diamondsPressed:(id) sender;

- (IBAction)spadesPressed:(id) sender;

- (IBAction)clubsPressed:(id) sender;

- (void)appendActiveLabel:(NSString*)withCard;

- (IBAction)backspacePressed:(id) sender;

- (IBAction)clearPressed:(id) sender;

- (IBAction)clearDoublePressed:(id)sender;

//- (IBAction)clearPressedUpInside:(id) sender;
//
//- (IBAction)clearPressedUpOutside:(id) sender;
//
//- (void)cancelClearAllTimer;
//
//- (IBAction)clearPressedDown:(id) sender;
//
//- (void)clearAll:(NSTimer*)theTimer;

- (IBAction)runPressed:(id) sender;

#ifdef USE_IN_APP_PURCHASE

@property (retain, nonatomic) NSMutableDictionary *privateDataFile;
@property (retain, nonatomic) NSString *formattedLocalFullVersionPrice;

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response;

- (void)showNagDialog;

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex;

- (void)purchaseFullVersion;

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions;
#endif


#ifdef USE_TRADITIONAL_LITE
- (void)showNagDialog;

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex;

#endif

- (IBAction)handLabelSelected:(id) sender;

- (IBAction)randomHandPressed:(id) sender;

- (IBAction)switchHandEquityPresentationPressed:(id) sender;

- (BOOL)validateActiveLabel;

- (BOOL)validateLabel:(UIButton *) label;

- (BOOL)run;

- (BOOL)checkHandCollision;

+ (BOOL)isCard:(NSString *) card;

- (int)countPlayers;

- (void)initWorker;

- (void)runWorker;

- (void)updateProgress;

+ (void)displayError:(NSString *)msg entitled:(NSString *)title;

- (void)applicationWillTerminate:(NSNotification *)notification;

- (NSString *)dataFilePath;

- (NSString *)settingsFilePath;

- (void)checkEasterEgg;

//returns the number of chars written to the handBuf for the player, or -error code if invalid hand
//+ (int)expandHands:(NSString*)handCode intoBuf:(char*)handBuf;


//- (IBAction)handLabelDblClicked:(id) sender;


@end

//returns the number of chars written to the handBuf for the player, or -error code if invalid hand
//int expandHands(NSString* handCode, char* handBuf);






