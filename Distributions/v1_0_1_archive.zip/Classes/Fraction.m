//
//  Fraction.m
//  sniper
//
//  Created by Mark Blackwell on 26/05/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Fraction.h"


@implementation Fraction

- (id)init {
	if (self = [super init]) {
		numerator = 0;
		denominator = 0;
	}
	
	return (self);
}

- (id)initWithNumerator:(int) ntor denominator:(int) dtor {
	if (self = [super init]) {
		numerator = ntor;
		denominator = dtor;
	}
	
	return (self);
}

- (id)initWithDecimal:(double) decimal {
	if (self = [super init]) {
		Fraction * temp = [Fraction convertFromDecimal:decimal withMaxDenominator:100];
		numerator = temp.numerator;
		denominator = temp.denominator;
	}
	
	return (self);
}

- (NSString *)description {
	NSMutableString * rv = [[NSMutableString alloc] init];
	[rv appendString:[NSString stringWithFormat:@"%d", numerator]];
	[rv appendString:@"/"];
	[rv appendString:[NSString stringWithFormat:@"%d", denominator]];
	
	return ([rv description]);
}

+ (Fraction *)convertFromDecimal:(double) decimal withMaxDenominator:(int) maxDenom {
	int numerator = 0;
	int denominator = 0;
	
	//	begin 
//	if  Decimal<0.0  then  DecimalSign := 1.0  else  DecimalSign := 1.0; 
	int decimalSign = 1;
	if (decimal < 0.0)
		decimalSign = -1;
	
//	Decimal := Abs(Decimal); 
	decimal = fabs(decimal);
//	if Decimal=Int(Decimal) then         handles exact integers including 0 
	if (decimal == floor(decimal)) { //handles exact integers including 0 
		numerator = decimal * decimalSign;
		denominator = 1;
	}
	else if (decimal < 1.0e-8) {
//		FractionNumerator := DecimalSign; 
		numerator = decimalSign;
		denominator = 99999999; 
	}
	else if (decimal > 1.0e8) {
		numerator = 99999999 * decimalSign; 
		denominator = 1.0; 
	}
	else {
		double z = decimal;
		int prevDenom = 0;
		denominator = 1; 
		while (denominator < maxDenom && z != floor(z)) {
			z = 1.0 / (z - floor(z));
			int temp = denominator;
			denominator = denominator * floor(z) + prevDenom;
			prevDenom = temp;
			numerator = ceil(decimal * denominator);
		}
		
		numerator *= decimalSign;
	}
	
	Fraction* rv = [[Fraction alloc] initWithNumerator:numerator denominator:denominator];
	
	return ([rv autorelease]);
	
}

@synthesize numerator;
@synthesize denominator;


@end
