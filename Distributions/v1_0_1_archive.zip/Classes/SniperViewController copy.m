//
//  sniperViewController.m
//  sniper
//
//  Created by Mark Blackwell on 28/03/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "SniperViewController.h"

@implementation SniperViewController

@synthesize lastSim;

- (void)viewDidLoad {
	//NSLog(@"Starting...");
	
	[self handLabelSelected:playerOneHand];
	
	stopSign = [UIImage imageNamed:@"50px-Stop_cross.png"];
	
	playerHands[0] = playerOneHand;
	playerHands[1] = playerTwoHand;
	playerHands[2] = playerThreeHand;
	playerHands[3] = playerFourHand;
	
	//title seems to be nil in OS3.0 builds, which interferes with operation
	int p;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++)
		[playerHands[p] setTitle:@"" forState:UIControlStateNormal];
	[flop setTitle:@"" forState:UIControlStateNormal];
	
	playerEqs[0] = playerOneEq;
	playerEqs[1] = playerTwoEq;
	playerEqs[2] = playerThreeEq;
	playerEqs[3] = playerFourEq;
	
	playerOdds[0] = playerOneOdds;
	playerOdds[1] = playerTwoOdds;
	playerOdds[2] = playerThreeOdds;
	playerOdds[3] = playerFourOdds;	
	
	playerWins[0] = playerOneWins;
	playerWins[1] = playerTwoWins;
	playerWins[2] = playerThreeWins;
	playerWins[3] = playerFourWins;	
	
	playerLosses[0] = playerOneLosses;
	playerLosses[1] = playerTwoLosses;
	playerLosses[2] = playerThreeLosses;
	playerLosses[3] = playerFourLosses;	
	
	playerTies[0] = playerOneTies;
	playerTies[1] = playerTwoTies;
	playerTies[2] = playerThreeTies;
	playerTies[3] = playerFourTies;	
	
	NSString *archivePath = [self dataFilePath];
	if ([[NSFileManager defaultManager] fileExistsAtPath:archivePath]) {
		NSLog(@"Recovering last sim...");
		
		self.lastSim = [NSKeyedUnarchiver unarchiveObjectWithFile:archivePath];
		
		NSString *handCode;
		int i;
		for (i = 0; i < MAX_PLAYERS_ON_SCREEN; i++) {
			if ((handCode = [lastSim.handCodes objectForKey:[NSString stringWithFormat:@"%d", i]]) != nil)
				[playerHands[i] setTitle:handCode forState:UIControlStateNormal];
		}
		
		if ((handCode = [lastSim.handCodes objectForKey:FLOP_STRING_ARCHIVE_KEY]) != nil)
			[flop setTitle:handCode forState:UIControlStateNormal];
		
		[self updateProgress];
	}
	else {
		//this has the same lifetime as the app, so no need to release it...
		self.lastSim = [[Simulation alloc] init];
	}
	
	UIApplication *app = [UIApplication sharedApplication];
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(applicationWillTerminate:)
											 name:UIApplicationWillTerminateNotification
											 object:app];
	
	[NSThread detachNewThreadSelector:@selector(initWorker) toTarget:self withObject:nil];
	
	[super viewDidLoad];
}

- (NSString *)dataFilePath {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *docsDirectory = [paths objectAtIndex:0];
	return [docsDirectory stringByAppendingPathComponent:ARCHIVE_NAME];
}

- (void)initWorker {
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	if (!isHandEvalInited) {
		//how do i lock isHandEvalInited?  could use a C semaphore??
		//NSLog(@"Initialising 0...");
						
		//NSLog(@"Initialising 1...");
		//init_deck(&deck);
		
		NSString *appPath = [[NSBundle mainBundle] resourcePath];
		
		//NSLog(@"Initialising 2...");
		
		appPath = [appPath stringByAppendingString:@"/"];
		
		//NSLog(@"Initialising 3...");
		//NSString *appDir = [appPath stringByDeletingPathExtension];
		char buf[1024];
		[appPath getCString:buf maxLength:512 encoding:NSASCIIStringEncoding];
		
		NSLog(@"Initialising 4...");
		
		handeval_init(buf);
		
		//NSLog(@"Initialising 5...");
		
		init_random ( time(NULL) );
		
		//NSLog(@"Initialising 6...");
		
		//numIters.text = @"Init'd";
		NSLog(@"Finished initialising");
		
		isHandEvalInited = YES;
		
	}
	
	[pool release];

}

- (IBAction)buttonPressed:(id) sender {
	UIButton *btn = (UIButton*)sender;
	
	//NSLog([NSString stringWithFormat:@"entering buttonPressed %@", activeLabel.currentTitle]);
	
	[self appendActiveLabel:btn.currentTitle];
	
	[self validateActiveLabel];
	
	//NSLog([NSString stringWithFormat:@"exiting buttonPressed %@", activeLabel.currentTitle]);
}

- (void)appendActiveLabel:(NSString*)card {
	if (activeLabel != nil) {
		//NSLog([NSString stringWithFormat:@"appending %@", card]);
		[activeLabel setTitle:[activeLabel.currentTitle stringByAppendingString:card] forState:UIControlStateNormal];
	}
}

- (IBAction)heartsPressed:(id) sender {
	[self appendActiveLabel:@"h"];
	
	[self validateActiveLabel];
}

- (IBAction)diamondsPressed:(id) sender {
	[self appendActiveLabel:@"d"];
	
	[self validateActiveLabel];
}

- (IBAction)spadesPressed:(id) sender {
	[self appendActiveLabel:@"s"];
	
	[self validateActiveLabel];
}

- (IBAction)clubsPressed:(id) sender {
	[self appendActiveLabel:@"c"];
	
	[self validateActiveLabel];
}

- (IBAction)runPressed:(id) sender {
	if (isWorking && isWorkerCancelled) {
		//do nothing... wait for the cancellation to take effect
	}
	else if (isWorking) {
		isWorkerCancelled = YES;
		//change image to = sign
		[runButton setTitle:@"=" forState:UIControlStateNormal];
		[runButton setImage:nil forState:UIControlStateNormal];

	}
	else if (isHandEvalInited) {
		isWorkerCancelled = NO;
		
		if([self run]) {
			//change image to stop sign
			[runButton setTitle:@"" forState:UIControlStateNormal];
			[runButton setImage:stopSign forState:UIControlStateNormal];
		}
	}
	else {
		//hand eval not inited
		[SniperViewController displayError:@"PokerSniper hasn't quite finished initialising yet... please try again in a few moments"
								  entitled:@"Sorry..."];
	}
	
	//NSLog(@"Leaving runPressed");
}

- (IBAction)backspacePressed:(id) sender {
	if (activeLabel != nil) {
		NSUInteger len = [activeLabel.currentTitle length];
		if (len > 0)
			[activeLabel setTitle:[activeLabel.currentTitle substringToIndex:(len - 1)] forState:UIControlStateNormal];
		
		[self validateActiveLabel];
	}
}

- (IBAction)clearPressed:(id) sender {
	if (activeLabel != nil)
		[activeLabel setTitle:@"" forState:UIControlStateNormal];
}

- (IBAction)clearDoublePressed:(id)sender {
	int p;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++)
		[playerHands[p] setTitle:@"" forState:UIControlStateNormal];
	
	[flop setTitle:@"" forState:UIControlStateNormal];
	
	[lastSim reset];
	
	[self updateProgress];
}


- (IBAction)clearPressedUpInside:(id) sender {
	[self cancelClearAllTimer];
	
	if (doClearAll) {
		int p;
		for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++)
			[playerHands[p] setTitle:@"" forState:UIControlStateNormal];
		
		//if (!isWorking)
		//[self updateProgress];
		
		doClearAll = NO;
	}
	else {
		if (activeLabel != nil)
			[activeLabel setTitle:@"" forState:UIControlStateNormal];
	}
}

- (IBAction)clearPressedUpOutside:(id) sender {
	[self cancelClearAllTimer];
}

- (void)cancelClearAllTimer {
	if (clearAllTimer != nil ) {
		NSLog(@"cancelling\n");
		[clearAllTimer invalidate];
		clearAllTimer = nil;
		NSLog(@"cancelled\n");
	}
}

- (IBAction)clearPressedDown:(id) sender {
	NSLog(@"Clear pressed down");
	
	clearAllTimer = [NSTimer scheduledTimerWithTimeInterval:CLR_ALL_INTERVAL_SECS
													 target:self 
												   selector:@selector(clearAll:) 
												   userInfo:nil
													repeats:NO];
}

- (void)clearAll:(NSTimer*)theTimer {
	doClearAll = YES;
}

- (IBAction)handLabelSelected:(id)sender {
	//remove any existing highlight
	if (activeLabel != nil)
		activeLabel.backgroundColor = nil;			
	
	
	activeLabel = (UIButton*)sender;
		
	//highlight selection white
	activeLabel.backgroundColor = [UIColor whiteColor];
	
	
}

- (IBAction)randomHandPressed:(id) sender {
	if (activeLabel == nil)
		return;
	
	if (activeLabel == flop) 
		return;
	
	[activeLabel setTitle:@"xxxx" forState:UIControlStateNormal];
}

- (BOOL)validateActiveLabel {
	if (![self validateLabel:activeLabel]) {
		[activeLabel setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
		//NSLog([NSString stringWithFormat:@"Invalid label %@", activeLabel.currentTitle]);
		return NO;
	}
	
	[activeLabel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
	//NSLog([NSString stringWithFormat:@"Valid label %@", activeLabel.currentTitle]);
	return YES;
}

- (BOOL)validateLabel:(UIButton *) label {
	//flop is separately validated
	if (label == flop)
		return YES;
	
	char validateBuf[256];
	[label.currentTitle getCString:validateBuf maxLength:256 encoding:NSASCIIStringEncoding];
	if (validateHand(validateBuf)) 
		return NO;
	
	return YES;
}

- (IBAction)switchHandEquityPresentationPressed:(id) sender {
	isResultsDisplaySwitched = !isResultsDisplaySwitched;
	
	if (!isWorking)
		[self updateProgress];
}

/*
- (BOOL)run {
	
	//user alert already occurred... just being defensive
	if (!isHandEvalInited)
		return NO;
		
	if ([self checkHandCollision])
		return NO;
		
	// including me
	lastSim.numPlayers = [self countPlayers];
	lastSim.numFlopped = 0;
	lastSim.hands = lastSim.buf;
	
	
	int charCount = 0;
	int p, validHandIx = 0;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		if ([playerHands[p].currentTitle isEqualToString:@""])
			continue;
			
		if (![self validateLabel:playerHands[p]]) {
			[SniperViewController displayError:[NSString stringWithFormat:@"Error in hand %d", p + 1] entitled:@"Whoops!"];
			
			return NO;
		}
		
		charCount = expandHands(playerHands[p].currentTitle, lastSim.hands);
		if (charCount > 0) {
			lastSim.hands += charCount;
			//this should be a round number...
			lastSim.numHands[validHandIx++] = charCount / (PODDS_NUM_DEALT_CARDS * PODDS_CHARS_PER_CARD);
		}
		else {
			//report error
			NSString *errStr = [NSString stringWithCString:getError() encoding:NSASCIIStringEncoding];
			[SniperViewController displayError:errStr entitled:[NSString stringWithFormat:@"Error in hand %d", p + 1]];
						
			return NO;
		}
	}
	
	//parse the flop cards
	NSString *flopStr = flop.currentTitle;
	int i;
	
	//must be an even number of characters (number plus suit for each card)
	BOOL isErr = ((flopStr.length % 2) != 0);
	NSRange rng;
	rng.location = 0;
	rng.length = 2;
	while (!isErr && (rng.location + rng.length) <= flopStr.length) {
		isErr = !([SniperViewController isCard:[flopStr substringWithRange:rng]]);
		rng.location += 2;
	}
	
	if (isErr) {
		[SniperViewController displayError:@"Cards must each have card and rank" entitled:@"Error in flop"];
		
		return NO;
	}
	
	//store the flop cards at the end of the hand buffer
	lastSim.flop = lastSim.hands;
	lastSim.numFlopped = flopStr.length / 2;
	
	char* flopStartMarker = lastSim.flop;
	rng.location = 0;
	rng.length = 2;
	for (i = 0; i < lastSim.numFlopped; i++) {
		
		//HACK: assumes that the buffer has 10 characters available
		[[flopStr substringWithRange:rng] getCString:lastSim.flop maxLength:10 encoding:NSASCIIStringEncoding];
		lastSim.flop[2] = '\0';
		lastSim.flop += PODDS_CHARS_PER_CARD;
		rng.location += 2;
	}
	
	//return the flop pointer to the start of the flop
	lastSim.flop = flopStartMarker;
	
	//return hands pointer to start of buffer
	lastSim.hands = lastSim.buf;
	
	//this is really the max number, b/c user will probably stop first
	lastSim.numSims = 1000000;
			
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		lastSim.results[p].rounds = 0;
		lastSim.results[p].player = lastSim.numPlayers;
		lastSim.results[p].won = 0;
		lastSim.results[p].split = 0;
		
		//released in the runPressed code
		//[playerHands[p].currentTitle retain];
	}	
		
	//NSLog(@"Launching worker...");
	
	//run processing in worker thread
	[NSThread detachNewThreadSelector:@selector(runWorker) toTarget:self withObject:nil];
	
	//NSLog(@"Worker started");
	
	return YES;
}
*/
- (BOOL)run {
	
	//user alert already occurred... just being defensive
	if (!isHandEvalInited)
		return NO;
	
	if ([self checkHandCollision])
		return NO;
	
	[self checkEasterEgg];
	
	int p, blanks = 0; //, validHandIx = 0;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		if ([playerHands[p].currentTitle isEqualToString:@""]) {
			blanks++;
			continue;
		}
	}
	
	if (blanks == MAX_PLAYERS_ON_SCREEN) {
		[SniperViewController displayError:@"No hands entered!" entitled:@"Whoops!"];
		return NO;
	}
	
	// including me
	//int numPlayers = [self countPlayers];lastSim
	[lastSim reset];
	
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		if ([playerHands[p].currentTitle isEqualToString:@""])
			continue;
		
		if (![self validateLabel:playerHands[p]]) {
			[SniperViewController displayError:[NSString stringWithFormat:@"Error in hand %d", p + 1] entitled:@"Whoops!"];
			
			return NO;
		}
		
		if (![lastSim addPlayer:playerHands[p].currentTitle at:p]) {
			//report error
			NSString *errStr = [NSString stringWithCString:getError() encoding:NSASCIIStringEncoding];
			[SniperViewController displayError:errStr entitled:[NSString stringWithFormat:@"Error in hand %d", p + 1]];
			
			return NO;
		}
	}
	
	//parse the flop cards
	NSString *flopStr = flop.currentTitle;
	//int i;
	
	//must be an even number of characters (number plus suit for each card)
	BOOL isErr = ((flopStr.length % 2) != 0);
	NSRange rng;
	rng.location = 0;
	rng.length = 2;
	while (!isErr && (rng.location + rng.length) <= flopStr.length) {
		isErr = !([SniperViewController isCard:[flopStr substringWithRange:rng]]);
		rng.location += 2;
	}
	
	if (isErr) {
		[SniperViewController displayError:@"Cards must each have card and rank" entitled:@"Error in flop"];
		
		return NO;
	}
	
	[lastSim setFlopString:flopStr];
	
//	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
//		lastSim.results[p].player = numPlayers;
//	}	
	
	//NSLog(@"Launching worker...");
	
	//run processing in worker thread
	[NSThread detachNewThreadSelector:@selector(runWorker) toTarget:self withObject:nil];
	
	//NSLog(@"Worker started");
	
	return YES;
}

- (void)checkEasterEgg {
	int p; //, validHandIx = 0;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		if ([playerHands[p].currentTitle isEqualToString:@"J3s"]) {
		    [SniperViewController displayError:@"If you really played J3s, then not even PokerSniper can help you." 
									  entitled:@"Uh oh :)"];
			return;
		}
	}
}

+ (BOOL)isCard:(NSString*) card {
	BOOL isErr = (card.length != 2);
	int i;
	for (i = 0; (!isErr) && i < card.length; i++) {
		if (i % 2 == 0) {
			unichar number = [card characterAtIndex:i];
			isErr = (number != '2' &&
					 number != '3' &&
					 number != '4' &&
					 number != '5' &&
					 number != '6' &&
					 number != '7' &&
					 number != '8' &&
					 number != '9' &&
					 number != 'T' &&
					 number != 'J' &&
					 number != 'Q' &&
					 number != 'K' &&
					 number != 'A');
		}
		else {
			unichar suit = [card characterAtIndex:i];
			isErr = (suit != 'h' &&
					 suit != 'd' &&
					 suit != 'c' &&
					 suit != 's');
			
		}
	}
	
	return !isErr;
}

- (BOOL)checkHandCollision {
	
	//return NO;

	//check for >4 of the same rank	
	//check for >13 of the same suit
	//check for exact duplicate cards
	
	//take the first specified hands from each player
	//if a range is specified take only the left end of the range
	//ignore if more than one hand combo exists just take the first combo
	//because this makes hand collisions far less likely (ie. they will only
	//exist if every one of the player hands specifies that same card,
	//which is far more likely to be done as a range)
	NSMutableSet *dealtCards = [[NSMutableSet alloc] initWithCapacity:PODDS_NUM_CARDS];
	
	//90 gives access to all nums and letters...
	int suitsPerRank[90] = { 0 };
	
	//hack: splitting hands on any punctuation characters (not just +-, etc)
	NSCharacterSet *splitters = [NSCharacterSet punctuationCharacterSet];
	int p = 0;
	BOOL isCollision = NO;
	while (!isCollision) {
		NSString *hand;
		//check the dealt hands and the flop
		if (p < MAX_PLAYERS_ON_SCREEN)
			hand = playerHands[p].currentTitle;
		else if (p == MAX_PLAYERS_ON_SCREEN)
			hand = flop.currentTitle;
		else
			break;
		p++;
		
		if ([hand isEqual:@""])
			continue;
			
		//just take the first "hand" (which could be anything really... KQ, KdKh, K7s etc etc
		NSString *firstHand = [[hand componentsSeparatedByCharactersInSet:splitters] objectAtIndex:0];

		//if the first two characters are a card, then add then to the set of cards, checking for collisions
		NSRange rng;
		rng.location = 0;
		rng.length = 2;
		while (!isCollision && (rng.location + rng.length) <= firstHand.length) {
			NSString* card = [firstHand substringWithRange:rng];
			if ([SniperViewController isCard:card]) {
				if ([dealtCards containsObject:card]) {
					isCollision = YES;
					
					[SniperViewController displayError:[NSString stringWithFormat:@"'%@' occurs twice (or more!)", card]
											  entitled:@"Card overdealt!"];
					break; //out of while
				}
				else {
					[dealtCards addObject:card];
					
					//and add the rank to the suitsPerRank count
					unichar rank = [card characterAtIndex:0];	
					if (++suitsPerRank[(int)rank] > PODDS_NUM_SUITS) {
						isCollision = YES;
						[SniperViewController 
							displayError:[NSString stringWithFormat:@"'%c' occurs %d (or more) times", rank, suitsPerRank[(int)rank]]
							entitled:@"Card overdealt!"];
						break; //out of while
					}
				}
			}
			//if the first two characters are not a card, and they are legal, then they must be either two ranks
			//or have a random rank (or maybe suit for something like xhxh)
			else if (rng.location == 0) {
				int i;
				for (i = 0; i < 2; i++) {
					unichar rank = [card characterAtIndex:i];	
					//if 
					if (rank == RANDOM_ENTRY_CHAR)
						break;
					
					if (++suitsPerRank[(int)rank] > PODDS_NUM_SUITS) {
						isCollision = YES;
						[SniperViewController 
							displayError:[NSString stringWithFormat:@"'%c' occurs %d (or more) times", rank, suitsPerRank[(int)rank]]
							entitled:@"Card overdealt!"];
						break; //won't break out of while loop immediately, but will on next iter
					}
				}
				
			}
			
			rng.location += 2;
		}
	}

	
	[dealtCards release];
	
	return isCollision;
}

+ (void)displayError:(NSString *)msg entitled:(NSString *)title {
	UIAlertView *alert = [[UIAlertView alloc] 
						  initWithTitle:title
						  message:msg
						  delegate:nil 
						  cancelButtonTitle:@"OK" 
						  otherButtonTitles:nil];
	[alert show];
	[alert release];	
}

- (int)countPlayers {
	int p, count = 0;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		if (![playerHands[p].currentTitle isEqualToString:@""])
			count++;
	}
	
	return count;
}

- (void)runWorker {
	//NSLog(@"runWorker started");
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	isWorking = YES;
	
//	clock_t start, end;
//	double elapsed;
//	start = clock();
	
	//NSLog(@"Beginning sim");
		
	int i;
	for (i = 0; i < lastSim.numSims && !isWorkerCancelled; i++) {
		if (i != 0 && (i % UPDATE_EQ_FREQ) == 0) {
			[self performSelectorOnMainThread:@selector(updateProgress)
								   withObject:nil
								waitUntilDone:YES];
		}
				
		runSimulation(lastSim.hands, lastSim.numPlayers, lastSim.numHands, 
					  lastSim.flop, lastSim.numFlopped, lastSim.results);
	}
	
	//in practice the cancellation check always seems to occur while the screen updating is taking place
	//so we don't miss out on any simulations by not displaying the final state... and also means that
	//an even number of sims will be displayed, rather than one more
	
//	[self performSelectorOnMainThread:@selector(updateProgress)
//						   withObject:nil
//						waitUntilDone:YES];
	
//	end = clock();
//	elapsed = ((double) (end - start)) / CLOCKS_PER_SEC;
	
	isWorking = NO;
	
    [pool release];
}

- (void)updateProgress {
	int p, activeIx = 0;
	for (p = 0; p < MAX_PLAYERS_ON_SCREEN; p++) {
		if (![playerHands[p].currentTitle isEqualToString:@""]) {
			
			//hand collisions may mean no rounds are played... hopefully stopped before this point
			if (lastSim.results[activeIx].rounds == 0) {
				continue;
			}
			
			double equity = ((0.5 * lastSim.results[activeIx].split) + lastSim.results[activeIx].won) / lastSim.results[activeIx].rounds;
			//convert equity to pot odds
			double odds = (1 - equity) / equity;
			
			if (!isResultsDisplaySwitched) {
				[playerEqs[p] setText:[NSString stringWithFormat:@"%1.1f%%", (equity * 100)]];			
				[playerOdds[p] setText:[NSString stringWithFormat:@"%1.1f\nto 1", odds]];
			}
			else {
				[playerEqs[p] setText:[NSString stringWithFormat:@"%1.1f to 1", odds]];			
				[playerOdds[p] setText:[NSString stringWithFormat:@"%1.0f%%", (equity * 100)]];
			}
			
			[playerEqs[p] setTextColor:[UIColor blackColor]];
			[playerOdds[p] setTextColor:[UIColor blackColor]];	
			
			int lost = lastSim.results[activeIx].rounds - (lastSim.results[activeIx].won + lastSim.results[activeIx].split);
			[playerWins[p] setText:[NSString stringWithFormat:@"W: %1.0f%%", 
									(float)lastSim.results[activeIx].won / lastSim.results[activeIx].rounds * 100]];
			[playerLosses[p] setText:[NSString stringWithFormat:@"L: %1.0f%%", 
									  (float)lost / lastSim.results[activeIx].rounds * 100]];
			[playerTies[p] setText:[NSString stringWithFormat:@"T: %1.0f%%", 
									(float)lastSim.results[activeIx].split / lastSim.results[activeIx].rounds * 100]];
			
			[playerWins[p] setTextColor:[UIColor blackColor]];
			[playerLosses[p] setTextColor:[UIColor blackColor]];
			[playerTies[p] setTextColor:[UIColor blackColor]];
			
			activeIx++;
		}
		else {
			if (!isResultsDisplaySwitched) {
				[playerEqs[p] setText:@"HE%"];
				[playerOdds[p] setText:@"X.X\nto 1"];		
			}
			else {
				[playerEqs[p] setText:@"X.X to 1"];
				[playerOdds[p] setText:@"HE%"];
			}
			
			[playerEqs[p] setTextColor:[UIColor grayColor]];
			[playerOdds[p] setTextColor:[UIColor grayColor]];	
			
			
			[playerWins[p] setText:@""];//"W:"];
			[playerLosses[p] setText:@""];//"L:"];
			[playerTies[p] setText:@""];//T:"];
			
			[playerWins[p] setTextColor:[UIColor grayColor]];
			[playerLosses[p] setTextColor:[UIColor grayColor]];
			[playerTies[p] setTextColor:[UIColor grayColor]];
		}
	}
	
	[numIters setText:[NSString stringWithFormat:@"%d", lastSim.results[0].rounds]];
}

- (void)applicationWillTerminate:(NSNotification *)notification {
	//save down the hands, flop and any result
	
	NSLog(@"Terminating...");
	
//	int i;
//	for (i = 0; i < MAX_PLAYERS_ON_SCREEN; i++) {
//		[lastSim.handCodes setObject:[playerHands[i] currentTitle] forKey:[NSString stringWithFormat:@"%d", i]];
//	}
	
	NSString *archivePath = [self dataFilePath];
	BOOL wasSuccess = [NSKeyedArchiver archiveRootObject:lastSim toFile:archivePath];
	
	NSLog([NSString stringWithFormat:@"Finished archiving... %d", wasSuccess]);
}


/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
    [super dealloc];
}

@end

//int expandHands(NSString* handCode, char* handBuf) {
//	char inbuf[1024];
//	
//	[handCode getCString:inbuf maxLength:1024 encoding:NSASCIIStringEncoding];
//	int charCount = getPossibleHands_csvHandCode(inbuf, handBuf);
//	
//	return charCount;
//}
