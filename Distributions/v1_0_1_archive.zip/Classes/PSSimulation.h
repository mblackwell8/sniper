//
//  PSSimulation.h
//  sniper
//
//  Created by Mark Blackwell on 27/04/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "podds.h"

@interface PSSimulation : NSObject {
	int numPlayers;
	int numHands[PODDS_MAX_PLAYERS + 1];
	int numSims;
	char *hands;
	
	int percentDone;
	
	simulation_result results;
}

@property int numPlayers;
@property int numHands[];
@property int numSims;
@property char *hands;

@property int percentDone;

@property simulation_result results;

@end
