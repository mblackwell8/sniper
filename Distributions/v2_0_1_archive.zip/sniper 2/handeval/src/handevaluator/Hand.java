package handevaluator;

public class Hand {

	public byte[] toByteArray() {
		// TODO Auto-generated method stub
		return null;
	}

}
