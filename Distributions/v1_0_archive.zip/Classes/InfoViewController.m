//
//  InfoViewController.m
//  sniper
//
//  Created by Mark Blackwell on 7/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "InfoViewController.h"


@implementation InfoViewController

@synthesize resourceFileName;

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	NSLog(@"IVC viewDidLoad called\n");
	
	if (!isViewLoaded) {
		NSString *urlAddress = [[NSBundle mainBundle] pathForResource:resourceFileName ofType:@"html"];
		
		//NSString *appPath = [[NSBundle mainBundle] resourcePath];
		//appPath = [NSString stringWithFormat:@"%@/%@", appPath, resourceFileName];
		
		NSURL *url = [NSURL fileURLWithPath:urlAddress];
		NSURLRequest *request = [NSURLRequest requestWithURL:url];
		//[[contentWebView mainFrame] loadRequest:request];
		[contentWebView loadRequest:request];
		
		isViewLoaded = YES;
	}
	
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	NSLog(@"IVC received mem warning\n");
	
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	NSLog(@"IVC viewDidUnload\n");
	
	isViewLoaded = NO;
	
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
