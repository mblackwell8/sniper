//
//  InfoViewController.h
//  sniper
//
//  Created by Mark Blackwell on 7/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface InfoViewController : UIViewController {
	//IBOutlet UILabel *infoLabel;
	IBOutlet UIWebView *contentWebView;
	IBOutlet UIScrollView *scroller;
	
	NSString *resourceFileName;
	
	BOOL isViewLoaded;
}

@property (retain, nonatomic) NSString *resourceFileName;

@end
