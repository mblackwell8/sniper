//
//  SwitchViewController.h
//  sniper
//
//  Created by Mark Blackwell on 7/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SniperViewController;
@class InfoViewController;

@interface SwitchViewController : UIViewController {
	SniperViewController *sniperVC;
	InfoViewController *helpInfoVC;
	InfoViewController *aboutInfoVC;
	
	UIViewController *currentVC;

}

- (IBAction)showHomeView:(id)sender;
- (IBAction)showAboutView:(id)sender;
- (IBAction)showHelpView:(id)sender;
//- (void)fillInfoView:(InfoViewController *) ivc withTextFromFile:(NSString *)infoFileName;
//- (void)showInfoView:(NSString *)infoFileName;
- (void)animateTransition:(UIViewAnimationTransition) transition 
				 incoming:(UIViewController *) coming 
				 outgoing:(UIViewController *) going;

@property (retain, nonatomic) IBOutlet SniperViewController *sniperVC;
@property (retain, nonatomic) IBOutlet InfoViewController *aboutInfoVC;
@property (retain, nonatomic) IBOutlet InfoViewController *helpInfoVC;
@property (retain, nonatomic) IBOutlet UIViewController *currentVC;


@end
