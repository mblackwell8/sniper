//
//  Fraction.h
//  sniper
//
//  Created by Mark Blackwell on 26/05/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <math.h>


@interface Fraction : NSObject {
	int numerator;
	int denominator;

}

- (id)init;

- (id)initWithNumerator:(int) numerator denominator:(int) denominator;

- (id)initWithDecimal:(double) decimal;

- (NSString *)description;

+ (Fraction *)convertFromDecimal:(double) decimal withMaxDenominator:(int) maxDenom;

//probably should put a parsing method in here...

//make immutable
@property (readonly) int numerator;
@property (readonly) int denominator;


@end
