#ifndef PODDS_H_
#define PODDS_H_

#include "carddeck.h"
//#include "common.h"
#include "handevaluator.h"
#include "randomgenerator.h"
#include "userinp.h"

//(PODDS_MAX_PLAYERS - 1) * PODDS_MAX_HANDS_PER_PLAYER * PODDS_NUM_DEALT_CARDS * PODDS_CHARS_PER_CARD
//must be < 1024 or need to increase buf
#define PODDS_MAX_PLAYERS 				7 //excluding me
#define PODDS_MAX_HANDS_PER_PLAYER 		20 //this is currently unchecked by userinp
#define PODDS_NUM_DEALT_CARDS		 	2
#define PODDS_CHARS_PER_CARD		 	3

#define PODDS_NUM_FLOP_CARDS		 	5
#define PODDS_NUM_CARDS 				52
#define PODDS_NUM_HAND_CARDS 			5
#define PODDS_LOWEST_HAND_SCORE 		7462
#define PODDS_NUM_SUITS 				4
#define PODDS_NUM_CARDS_PER_SUIT		13
#define PODDS_MAX_CHARS_PER_HAND		32  //the maximum length an individual hand string can be (something like 'AJs-AKs')
											//NB. includes the null terminator

//typedef struct simulation_result {
//	unsigned int rounds;
//	unsigned int player; /* Number of opponents (1 for heads-up) */
//	unsigned int won;
//	unsigned int split;
//	char card1, card2;
//	unsigned int winclasses[10], looseclasses[10];
//} simulation_result; 

char handBuf[(PODDS_MAX_PLAYERS + 1) * PODDS_NUM_DEALT_CARDS];
char* playedHands[PODDS_MAX_PLAYERS + 1];

//otherHands has an array entry for each other player, with a set of possible hands for each player
//numOtherHands laid out by player, specifying the number of possible hands that player has
int runSimulation(char* hands, int numPlayers, int numOtherHands[], char* flop, int numFlopped, simulation_result* results); 

//int ctoi(char* card);

//void printResults(simulation_result* result, int numPlayers);

#endif /*PODDS_H_*/
